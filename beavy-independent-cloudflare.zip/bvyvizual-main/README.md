# Beavy — site de prezentare

Site React + TanStack Start, pregătit pentru Cloudflare Workers. Proiectul nu mai folosește editorul, hostingul sau configurația Vite de la Lovable.

## Modificarea textelor

Textele site-ului sunt centralizate în:

`src/content.json`

Poți modifica titlurile, descrierile, butoanele, textele secțiunilor și datele de contact fără să cauți prin componentele React.

## Dezvoltare locală

Necesită Node.js 22+.

```bash
npm install
npm run dev
```

## Build și publicare pe Cloudflare Workers

```bash
npm run build
npx wrangler deploy
```

Conectează repository-ul la Cloudflare Workers Builds pentru publicare automată la fiecare push pe branch-ul `main`.

## Structură importantă

- `src/content.json` — textele site-ului
- `src/routes/index.tsx` — structura și designul paginii
- `src/assets/beavy-beaver.png` — imaginea mascotului
- `vite.config.ts` — Vite + TanStack Start + Cloudflare
- `wrangler.jsonc` — configurarea Worker-ului
