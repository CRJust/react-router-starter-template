import { createFileRoute } from "@tanstack/react-router";
import { ArrowRight, Leaf, Mail, Scale, Sparkles, Handshake } from "lucide-react";
import content from "@/content.json";
import beavyMascot from "@/assets/beavy-beaver.png";

const CONTACT = content.site.contact;
const PARTNER_MAIL = `mailto:${CONTACT}?subject=${encodeURIComponent("Hai să vorbim — Beavy")}`;

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: content.site.title },
      { name: "description", content: content.site.description },
      { property: "og:title", content: content.site.title },
      { property: "og:description", content: content.site.description },
      { property: "og:type", content: "website" },
      { property: "og:url", content: content.site.url },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "canonical", href: content.site.url }],
  }),
  component: Index,
});

const valueIcons = [Scale, Leaf, Sparkles];
const valueTones = ["bg-mint", "bg-accent", "bg-secondary"];

function Index() {
  return (
    <div className="flex min-h-screen flex-col overflow-x-hidden bg-background text-foreground">
      <header className="mx-auto flex w-full max-w-6xl items-center justify-between px-6 py-5">
        <a href="/" className="font-display text-3xl font-extrabold tracking-tight text-primary">
          {content.header.logo}<span className="text-coral">.</span>
        </a>
        <a
          href={PARTNER_MAIL}
          className="rounded-full border-2 border-foreground/10 px-4 py-2 text-sm font-semibold transition-colors hover:border-primary hover:text-primary"
        >
          {content.header.button}
        </a>
      </header>

      <main className="flex-1">
        <section className="relative mx-auto grid max-w-6xl items-center gap-10 px-6 pb-16 pt-8 md:grid-cols-[1.1fr_1fr] md:pt-14">
          <div>
            <span className="inline-flex items-center gap-2 rounded-full bg-mint px-4 py-1.5 text-sm font-semibold text-forest">
              <span aria-hidden>🌱</span> {content.hero.eyebrow}
            </span>
            <h1 className="mt-6 font-display text-5xl font-extrabold leading-[0.95] tracking-tight text-forest md:text-7xl">
              {content.hero.titleLine1} <span className="text-primary">{content.hero.titleAccent}</span>
              <br />
              <span className="relative inline-block">
                {content.hero.titleLine2}
                <span className="absolute -bottom-1 left-0 -z-10 h-4 w-full rounded-full bg-sun/70" aria-hidden />
              </span>
            </h1>
            <p className="mt-7 max-w-lg text-lg leading-relaxed text-muted-foreground">
              {content.hero.description}
            </p>
            <div className="mt-9 flex flex-wrap items-center gap-4">
              <a
                href="#parteneri"
                className="inline-flex items-center gap-2 rounded-full bg-primary px-7 py-3.5 font-semibold text-primary-foreground shadow-lg shadow-primary/25 transition-transform hover:-translate-y-0.5"
              >
                {content.hero.primaryCta} <ArrowRight className="h-4 w-4" aria-hidden />
              </a>
              <a href="#misiune" className="font-semibold text-forest underline-offset-4 hover:underline">
                {content.hero.secondaryCta}
              </a>
            </div>
          </div>

          <div className="relative mx-auto w-full max-w-md">
            <div className="absolute inset-4 rounded-full bg-sun/60 blur-2xl" aria-hidden />
            <div className="absolute right-0 top-6 h-24 w-24 rounded-full bg-coral/30" aria-hidden />
            <div className="absolute -left-2 bottom-10 h-16 w-16 rounded-full bg-mint" aria-hidden />
            <img
              src={beavyMascot}
              alt={content.hero.imageAlt}
              className="relative w-full drop-shadow-xl"
            />
          </div>
        </section>

        <section id="misiune" className="bg-card py-20">
          <div className="mx-auto max-w-6xl px-6">
            <p className="font-semibold text-coral">{content.mission.eyebrow}</p>
            <h2 className="mt-2 max-w-2xl font-display text-4xl font-bold leading-tight text-forest md:text-5xl">
              {content.mission.title}
            </h2>
            <p className="mt-5 max-w-2xl text-lg leading-relaxed text-muted-foreground">
              {content.mission.description}
            </p>
            <div className="mt-12 grid gap-5 md:grid-cols-3">
              {content.mission.values.map((value, index) => {
                const Icon = valueIcons[index] ?? Sparkles;
                return (
                  <div key={value.title} className={`rounded-3xl ${valueTones[index] ?? "bg-secondary"} p-7 transition-transform hover:-translate-y-1`}>
                    <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-card text-primary">
                      <Icon className="h-6 w-6" aria-hidden />
                    </div>
                    <h3 className="mt-5 font-display text-2xl font-bold text-forest">{value.title}</h3>
                    <p className="mt-2 leading-relaxed text-foreground/75">{value.text}</p>
                  </div>
                );
              })}
            </div>
          </div>
        </section>

        <section id="parteneri" className="px-6 py-20">
          <div className="mx-auto grid max-w-6xl items-center gap-10 overflow-hidden rounded-[2.5rem] bg-forest p-8 text-primary-foreground md:grid-cols-[1.2fr_1fr] md:p-14">
            <div>
              <span className="inline-flex items-center gap-2 rounded-full bg-primary-foreground/10 px-4 py-1.5 text-sm font-semibold">
                <Handshake className="h-4 w-4" aria-hidden /> {content.partners.eyebrow}
              </span>
              <h2 className="mt-5 font-display text-4xl font-bold leading-tight md:text-5xl">
                {content.partners.title}
              </h2>
              <p className="mt-5 max-w-lg text-lg leading-relaxed text-primary-foreground/80">
                {content.partners.description}
              </p>
              <a
                href={PARTNER_MAIL}
                className="mt-8 inline-flex items-center gap-3 rounded-full bg-sun px-7 py-3.5 font-semibold text-forest transition-transform hover:-translate-y-0.5"
              >
                <Mail className="h-5 w-5" aria-hidden /> {content.partners.button}
              </a>
              <p className="mt-4 text-sm text-primary-foreground/60">{content.partners.note}</p>
            </div>
            <div className="relative mx-auto w-full max-w-xs">
              <div className="absolute inset-6 rounded-full bg-sun/40 blur-2xl" aria-hidden />
              <img
                src={beavyMascot}
                alt={content.partners.imageAlt}
                className="relative w-full drop-shadow-2xl"
              />
            </div>
          </div>
        </section>
      </main>

      <footer className="pb-10">
        <div className="mx-auto flex max-w-6xl flex-col justify-between gap-3 px-6 text-sm text-muted-foreground md:flex-row">
          <p>
            <span className="font-display text-lg font-extrabold text-primary">{content.header.logo}</span> · {content.footer.tagline}
          </p>
          <p>beavy.ro · {CONTACT} · © {new Date().getFullYear()}</p>
        </div>
      </footer>
    </div>
  );
}
